
window.onload=function(){

    var today = new Date();
    var month = today.getMonth();
    var date = today.getDate();
    var week = today.getDay();
    var year = today.getFullYear();
    if(month==0){
        month="January";
    }
    else if(month==1){
        month = "Febuary";
    }
    else if(month==2){
        month = "March";
    }
    else if(month==3){
        month = "April";
    }
    else if(month==4){
        month = "May";
    }
    else if(month==5){
        month = "June";
    }
    else if(month==6){
        month = "July";
    }
    else if(month==7){
        month = "August";
    }
    else if(month==8){
        month = "September";
    }
    else if(month==9){
        month = "October";
    }
    else if(month==10){
        month = "November";
    }
    else if(month==11){
        month = "December";
    }
    
    if(week==0){
        week="Sunday";
    }
    else if(week==1){
        week = "Monday";
    }
    else if(week==2){
        week = "Tuesday";
    }
    else if(week==3){
        week = "Wednesday";
    }
    else if(week==4){
        week = "Thursday";
    }
    else if(week==5){
        week = "Friday";
    }
    else if(week==6){
        week = "Saturday";
    }
    document.querySelector('.month').innerHTML = month;
    document.querySelector('.date').innerHTML = date;
    document.querySelector('.week').innerHTML = week;
    document.querySelector('.year').innerHTML = year;
    const input = document.querySelector('.link');
       input.addEventListener("click",addList);
		function addList(e){
            
            location.href="cal.html"
        }
    function displayCurrentTime() { 
    
    var myDate = new Date();
    var hour = myDate.getHours();
    var minutes = myDate.getMinutes();
    var seconds = myDate.getSeconds();
    amPm(hour);
    hour= padSingleDigit(hour);
    document.querySelector(".hours").innerHTML= singledig(hour);  
    document.querySelector(".minutes").innerHTML= singledig(minutes);
    document.querySelector(".seconds").innerHTML= singledig(seconds);
    
 };
     
var timer = setInterval(displayCurrentTime,1000);

function amPm(hour){
    if(hour<=12){
        document.querySelector(".ampm").innerHTML="AM";
    }
    else{
     document.querySelector(".ampm").innerHTML="PM";
    }
};
    var singledig=function(n)
    {
        return(n<10)?"0"+n:n;
    }
    
function padSingleDigit(hour) {
	if (hour <= 12) {	
        return  hour ;
    }
	else { 
        return hour-12; 
    }
};
}
window.onload=function(){
const input = document.querySelector('input');
const btn = document.querySelector('.addTask > button');
const back = document.querySelector('.back');
btn.addEventListener("click",addList);
		function addList(e)
    {
			const notdone = document.querySelector('.notdone');
			const done = document.querySelector('.done');

			const newLi = document.createElement('li');
			const checkBtn = document.createElement('button');
			const delBtn = document.createElement('button');

			checkBtn.innerHTML = '<i class="fa fa-check"></i>';
			delBtn.innerHTML = '<i class="fa fa-trash"></i>';


			if(input.value !==''){
				newLi.textContent = input.value;
				input.value = '';
				notdone.appendChild(newLi);
				newLi.appendChild(checkBtn);
				newLi.appendChild(delBtn);
			}
      checkBtn.addEventListener('click', function(){
				const parent = this.parentNode;
				parent.remove();
				done.appendChild(parent);
				checkBtn.style.display = 'none';
			});
			
  
    delBtn.addEventListener('click', function(){
				const parent = this.parentNode;
				parent.remove();
			});
     
            
			
		}
    back.addEventListener("click",add);
    function add(e)
    {
        location.href="index.html";
    }
   
    
 }